"use strict";

/**
 * --------------------------------------------------------------------------
 * CoreUI Free Boostrap Admin Template (v2.1.15): tooltips.js
 * Licensed under MIT (https://coreui.io/license)
 * --------------------------------------------------------------------------
 */
$('[data-toggle="tooltip"]').tooltip();
//# sourceMappingURL=tooltips.js.map